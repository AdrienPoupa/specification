import airport.AirportManagement;

public class Main {
    public static void main(String[] args){
        AirportManagement airport = new AirportManagement(3, 4);
    }
}
